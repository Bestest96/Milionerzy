CREATE TRIGGER TG2
AFTER UPDATE
  ON PRACOWNICY
FOR EACH ROW
  DECLARE
v_max_placa NUMBER(7, 2);
BEGIN
SELECT MAX_PLACA
INTO v_max_placa
FROM STANOWISKA
WHERE kod_stanowiska = :new.kod_stanowiska;
dbms_output.put_line('Różnica: ' || (v_max_placa - :new.zarobki));
END;
/
