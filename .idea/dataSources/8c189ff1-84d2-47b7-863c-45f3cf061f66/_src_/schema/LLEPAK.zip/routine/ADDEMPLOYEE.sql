CREATE PROCEDURE addEmployee
(
  p_id_pracownika NUMBER,
  p_imie_pracownika VARCHAR2,
  p_nazwisko_pracownika VARCHAR2,
  p_zarobki_pracownika NUMBER,
  p_nazwa_stanowiska VARCHAR2,
  p_nazwa_zakladu VARCHAR2,
  p_imie_kierownika VARCHAR2,
  p_nazwisko_kierownika VARCHAR2
) 
AS
  --definicja zmiennych lokalnych
  v_kod_stanowiska STANOWISKA.KOD_STANOWISKA%TYPE;
  v_id_zakladu ZAKLADY.ID_ZAKLADU%TYPE;
  v_id_kierownika PRACOWNICY.ID_KIEROWNIKA%TYPE;
BEGIN
  SELECT KOD_STANOWISKA INTO v_kod_stanowiska
  FROM STANOWISKA WHERE NAZWA LIKE p_nazwa_stanowiska;
  SELECT ID_ZAKLADU INTO v_id_zakladu
  FROM ZAKLADY WHERE NAZWA_ZAKLADU LIKE p_nazwa_zakladu;
  
  SELECT ID_PRACOWNIKA INTO v_id_kierownika
  FROM PRACOWNICY WHERE IMIE LIKE p_imie_kierownika 
    AND NAZWISKO LIKE p_nazwisko_kierownika;
  
  INSERT INTO pracownicy values (p_id_pracownika, p_imie_pracownika,
    p_nazwisko_pracownika, p_zarobki_pracownika, SYSDATE, v_id_zakladu,
    v_id_kierownika, v_kod_stanowiska);
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    dbms_output.put_line('Sprawdz ponownie nazwe zakladu, 
    lub nazwe stanowiska lub dane kierownika');
END addEmployee;
/
