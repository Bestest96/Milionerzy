CREATE FUNCTION f1
DROP TABLE Odpowiedzi;
DROP TABLE Pytania;
DROP SEQUENCE pytID;
DROP SEQUENCE odpID;

CREATE TABLE Pytania (
    ID_Pytania NUMBER(5) PRIMARY KEY,
    Pytanie VARCHAR2(1000 CHAR) NOT NULL,
    Poziom VARCHAR2(1 CHAR) NOT NULL, CONSTRAINT kat CHECK (Poziom IN ('Ł', 'Ś', 'T'))
    );

CREATE TABLE Odpowiedzi (
    ID_Odpowiedzi NUMBER(5) PRIMARY KEY,
    Odpowiedz VARCHAR2(1000 CHAR) NOT NULL,
    Czy_Prawidlowa CHAR(1 CHAR) NOT NULL, CONSTRAINT bool CHECK (Czy_Prawidlowa IN ('T', 'N')),
    ID_Pytania NUMBER(5),
    FOREIGN KEY (ID_Pytania) REFERENCES Pytania(ID_Pytania) ON DELETE CASCADE
    );

CREATE SEQUENCE pytID
START WITH 1
INCREMENT BY 1;

CREATE SEQUENCE odpID
START WITH 1
INCREMENT BY 1;

SELECT pytID.value FROM DUAL;

INSERT INTO Pytania VALUES (qID, 'W którym roku miał miejsce chrzest Polski?', 'Ł');

Insert INTO Odpowiedzi VALUES (odpID.nextval, '966', 'T', qID);
Insert INTO Odpowiedzi VALUES (odpID.nextval, '988', 'N', qID);
Insert INTO Odpowiedzi VALUES (odpID.nextval, '1025', 'N', qID);
Insert INTO Odpowiedzi VALUES (odpID.nextval, '1000', 'N', qID);
/
