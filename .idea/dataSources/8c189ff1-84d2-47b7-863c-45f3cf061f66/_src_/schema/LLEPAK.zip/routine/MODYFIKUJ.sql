CREATE PROCEDURE modyfikuj (
  zmienna1 IN NUMBER, 
  zmienna2 IN OUT NUMBER, 
  zmienna3 OUT NUMBER
  )
AS
BEGIN
dbms_output.put_line(zmienna1 || ' ' || 
                     zmienna2 || ' ' || 
                     zmienna3); -- prosze zauwazyc puste miejsce dla zmienna3 
                                -- (dlatego, ze posiada wt. NULL)
                                
--zmienna1 := 2; --próba przypisania wt. do zmiennej typu IN kończy się bledem
zmienna2 := 30;
zmienna3 := 40;
END modyfikuj; --koniec procedury
/
