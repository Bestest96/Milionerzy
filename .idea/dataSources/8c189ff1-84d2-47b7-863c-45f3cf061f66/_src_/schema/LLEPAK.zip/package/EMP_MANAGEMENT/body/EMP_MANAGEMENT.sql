CREATE PACKAGE BODY emp_management IS
PROCEDURE addEmployee
(
  p_id_pracownika NUMBER,
  p_imie_pracownika VARCHAR2,
  p_nazwisko_pracownika VARCHAR2,
  p_zarobki_pracownika NUMBER,
  p_nazwa_stanowiska VARCHAR2,
  p_nazwa_zakladu VARCHAR2,
  p_imie_kierownika VARCHAR2,
  p_nazwisko_kierownika VARCHAR2
) 
AS
  --definicja zmiennych lokalnych
  v_kod_stanowiska STANOWISKA.KOD_STANOWISKA%TYPE;
  v_id_zakladu ZAKLADY.ID_ZAKLADU%TYPE;
  v_id_kierownika PRACOWNICY.ID_KIEROWNIKA%TYPE;
BEGIN
  SELECT KOD_STANOWISKA INTO v_kod_stanowiska
  FROM STANOWISKA WHERE NAZWA LIKE p_nazwa_stanowiska;
  SELECT ID_ZAKLADU INTO v_id_zakladu
  FROM ZAKLADY WHERE NAZWA_ZAKLADU LIKE p_nazwa_zakladu;
  
  SELECT ID_PRACOWNIKA INTO v_id_kierownika
  FROM PRACOWNICY WHERE IMIE LIKE p_imie_kierownika 
    AND NAZWISKO LIKE p_nazwisko_kierownika;
  
  INSERT INTO pracownicy values (p_id_pracownika, p_imie_pracownika,
    p_nazwisko_pracownika, p_zarobki_pracownika, SYSDATE, v_id_zakladu,
    v_id_kierownika, v_kod_stanowiska);
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    dbms_output.put_line('Sprawdz ponownie nazwe zakladu, 
    lub nazwe stanowiska lub dane kierownika');
END addEmployee;
FUNCTION maxSalaryByDept
RETURN NUMBER
AS
CURSOR c IS 
  SELECT ZAKLADY.ID_ZAKLADU, AVG(ZAROBKI) as AVG_ZAROBKI
  FROM ZAKLADY
  JOIN PRACOWNICY ON ZAKLADY.ID_ZAKLADU = PRACOWNICY.ID_ZAKLADU
  GROUP BY ZAKLADY.ID_ZAKLADU;

maximum PRACOWNICY.ZAROBKI%TYPE := -100;
BEGIN
FOR i IN c
LOOP
  IF i.AVG_ZAROBKI > maximum THEN
    maximum := i.AVG_ZAROBKI;
  END IF;
END LOOP;

RETURN maximum;
END;
PROCEDURE reserveTicket 
(
  tick_id TICKETS.TICKET_ID%TYPE,
  prac_id PRACOWNICY.ID_PRACOWNIKA%TYPE
)
AS
  tick_poll TICKETS.TICKET_POLL%TYPE;
  tid TICKETS.TICKET_ID%TYPE;
  pid PRACOWNICY.ID_PRACOWNIKA%TYPE;
BEGIN
  SELECT TICKET_POLL INTO tick_poll
  FROM TICKETS
  WHERE TICKET_ID = tick_id;
  
  SELECT ID_PRACOWNIKA into pid
  FROM PRACOWNICY
  WHERE ID_PRACOWNIKA = prac_id;
  
  SELECT TICKET_ID INTO tid
  FROM TICKETS
  WHERE TICKET_ID = tick_id;
  
  IF tick_poll <= 0 THEN
    dbms_output.put_line('NO MORE TICKETS!');
  ELSIF pid = NULL THEN
    dbms_output.put_line('NO EMPLOYEE FOUND!');
  ELSIF tid = NULL THEN
    dbms_output.put_line('NO TICKET FOUND!');
  ELSE
    INSERT INTO TICKETS_EMP VALUES (reservSeq.nextval, tick_id, prac_id);
    UPDATE TICKETS
    SET TICKET_POLL = TICKET_POLL - 1
    WHERE TICKET_ID = tick_id;
    dbms_output.put_line('TICKET RESERVED!');
  END IF;
END;

END emp_management;
/
