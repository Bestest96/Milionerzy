CREATE PACKAGE emp_management IS
PROCEDURE addEmployee 
(
  p_id_pracownika NUMBER,
  p_imie_pracownika VARCHAR2,
  p_nazwisko_pracownika VARCHAR2,
  p_zarobki_pracownika NUMBER,
  p_nazwa_stanowiska VARCHAR2,
  p_nazwa_zakladu VARCHAR2,
  p_imie_kierownika VARCHAR2,
  p_nazwisko_kierownika VARCHAR2
) ;

FUNCTION maxSalaryByDept
RETURN NUMBER ;

PROCEDURE reserveTicket
(
  tick_id TICKETS.TICKET_ID%TYPE,
  prac_id PRACOWNICY.ID_PRACOWNIKA%TYPE
);

END emp_management;
/
